import json
import boto3

def lambda_handler(event, context):
    secret_name = "example-secret"
    region_name = "us-west-2"
    
    # Create a Secrets Manager client
    client = boto3.client('secretsmanager', region_name=region_name)
    
    try:
        get_secret_value_response = client.get_secret_value(SecretId=secret_name)
    except Exception as e:
        raise e
    else:
        if 'SecretString' in get_secret_value_response:
            secret = json.loads(get_secret_value_response['SecretString'])
            username = secret['username']
            password = secret['password']
            return {
                'statusCode': 200,
                'body': json.dumps(f"Username: {username}, Password: {password}")
            }
        else:
            binary_secret_data = get_secret_value_response['SecretBinary']
            return {
                'statusCode': 200,
                'body': json.dumps(f"Binary data: {binary_secret_data}")
            }
